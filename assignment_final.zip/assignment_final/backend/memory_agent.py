from neo4j import GraphDatabase
from neo4j.exceptions import ServiceUnavailable

class MemoryAgent:
    def __init__(self, uri, user, password):
        try:
            self.driver = GraphDatabase.driver(uri, auth=(user, password))
        except ServiceUnavailable as e:
            print(f"Failed to connect to the Neo4j database: {e}")
            raise

    def close(self):
        try:
            self.driver.close()
        except Exception as e:
            print(f"Error closing Neo4j connection: {e}")

    def add_preference(self, user_id: str, preference: str):
        try:
            with self.driver.session() as session:
                session.run(
                    "MERGE (u:User {id: $user_id}) "
                    "MERGE (p:Preference {name: $preference}) "
                    "MERGE (u)-[:LIKES]->(p)",
                    user_id=user_id, preference=preference
                )
        except Exception as e:
            print(f"Error adding preference: {e}")

    def add_preferences_batch(self, user_id: str, preferences: list):
        """Add multiple preferences for a user in one batch."""
        try:
            with self.driver.session() as session:
                for preference in preferences:
                    session.run(
                        "MERGE (u:User {id: $user_id}) "
                        "MERGE (p:Preference {name: $preference}) "
                        "MERGE (u)-[:LIKES]->(p)",
                        user_id=user_id, preference=preference
                    )
        except Exception as e:
            print(f"Error adding preferences in batch: {e}")

    def get_preferences(self, user_id: str):
        try:
            with self.driver.session() as session:
                result = session.run(
                    "MATCH (u:User {id: $user_id})-[:LIKES]->(p:Preference) "
                    "RETURN p.name",
                    user_id=user_id
                )
                return [record["p.name"] for record in result]
        except Exception as e:
            print(f"Error fetching preferences: {e}")
            return []
