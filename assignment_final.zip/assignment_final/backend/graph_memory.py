# backend/graph_memory.py

from neo4j import GraphDatabase, exceptions

class GraphMemory:
    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))

    def close(self):
        self.driver.close()

    def add_triplet(self, entity1, relationship, entity2):
        """Store an entity-relationship-entity triplet in the graph."""
        with self.driver.session() as session:
            session.run(
                "MERGE (e1:Entity {name: $entity1}) "
                "MERGE (e2:Entity {name: $entity2}) "
                "MERGE (e1)-[r:RELATIONSHIP {type: $relationship}]->(e2)",
                entity1=entity1, relationship=relationship, entity2=entity2
            )

    def query_memory(self, entity, relationship=None):
        """Query memory related to a specific entity and optionally a relationship."""
        with self.driver.session() as session:
            if relationship:
                result = session.run(
                    "MATCH (e1:Entity {name: $entity})-[r:RELATIONSHIP {type: $relationship}]->(e2) "
                    "RETURN e2.name AS related_entity", entity=entity, relationship=relationship
                )
            else:
                result = session.run(
                    "MATCH (e1:Entity {name: $entity})-[r]->(e2) "
                    "RETURN e2.name AS related_entity"
                )
            return [record["related_entity"] for record in result]

    def update_triplet(self, entity1, relationship, entity2):
        """Update an existing triplet or create it if not present."""
        self.add_triplet(entity1, relationship, entity2)

    def store_triplets(self, triplet_text):
        """Store multiple triplets in the graph from a triplet response string."""
        triplets = triplet_text.strip().splitlines()

        with self.driver.session() as session:
            for triplet in triplets:
                try:
                    # Check if triplet is correctly formatted
                    parts = triplet.split('-')
                    if len(parts) != 3:
                        print(f"Skipping malformed triplet: {triplet}")
                        continue
                    
                    entity1, relationship, entity2 = map(str.strip, parts)
                    
                    # Ensure that none of the entities or relationships are empty
                    if not entity1 or not relationship or not entity2:
                        print(f"Skipping incomplete triplet: {triplet}")
                        continue
                    
                    # Insert the triplet into the graph
                    session.run(
                        "MERGE (a:Entity {name: $entity1}) "
                        "MERGE (b:Entity {name: $entity2}) "
                        "MERGE (a)-[r:RELATION {type: $relationship}]->(b)",
                        entity1=entity1, relationship=relationship, entity2=entity2
                    )
                except exceptions.Neo4jError as e:
                    print(f"Error storing triplet {triplet}: {e}")

