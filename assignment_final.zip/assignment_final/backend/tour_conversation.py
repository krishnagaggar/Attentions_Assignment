import re
import datetime
from backend.model_endpoint import generate_response_and_triplet
from backend.graph_memory import GraphMemory

def initialize_tour_request(graph_memory, request):
    """
    Initialize the tour request by storing the initial user preferences in the graph.
    """
    tour_request = {
        "user_id": request.user_id,
        "city": request.city,
        "preferences": request.preferences,
        "budget": request.budget,
        "days_of_stay": request.days_of_stay,
        "start_date": request.start_date
    }
    
    # Store the initial user preferences as triplets in the graph
    triplet_response = [
        (request.user_id, "wants to visit", request.city),
        (request.user_id, "preferences", ", ".join(request.preferences)),
        (request.user_id, "budget", request.budget),
        (request.user_id, "days_of_stay", str(request.days_of_stay)),
        (request.user_id, "start_date", request.start_date)
    ]
    graph_memory.store_triplets(triplet_response)
    
    # Generate a response for initial preferences
    paragraph_response = f"Initializing a one-day trip to {request.city} with preferences for {', '.join(request.preferences)} on a budget of ${request.budget}."
    return paragraph_response

def handle_dynamic_input(graph_memory, user_id, user_input):
    """
    Handle dynamic user input, update the graph, and generate responses.
    """
    # Extract dynamic details (city, preferences, budget, etc.) from user input
    city = None
    preferences = []
    budget = None
    days_of_stay = None
    start_date = None
    
    if "city" in user_input.lower() or "visit" in user_input.lower():
        city_match = re.search(r"(in|to|from)\s+(\w+)", user_input)
        if city_match:
            city = city_match.group(2)

    if "preferences" in user_input.lower() or "like" in user_input.lower():
        preferences = extract_preferences(user_input)

    if "budget" in user_input.lower():
        budget_match = re.search(r"\$([0-9]+)", user_input)
        if budget_match:
            budget = int(budget_match.group(1))

    if "days" in user_input.lower():
        days_match = re.search(r"(\d+)\s+days", user_input)
        if days_match:
            days_of_stay = int(days_match.group(1))

    if "start" in user_input.lower() and "date" in user_input.lower():
        date_match = re.search(r"(\d{1,2}[\/\-\s]?\d{1,2}[\/\-\s]?\d{4})", user_input)
        if date_match:
            try:
                start_date = datetime.datetime.strptime(date_match.group(1), "%d/%m/%Y").date()
            except ValueError:
                pass  # Incorrect date format

    # Construct a tour request based on extracted information
    tour_request = {
        "user_id": user_id,
        "city": city,
        "preferences": preferences,
        "budget": budget,
        "days_of_stay": days_of_stay,
        "start_date": start_date
    }
    
    # Generate prompt and response
    prompt = f"User wants to adjust their trip to {city or 'current location'}. Preferences: {', '.join(preferences) if preferences else 'current preferences'}. " \
             f"Budget: ${budget if budget else 'current budget'}. Start date: {start_date if start_date else 'current start date'}."
    
    # Get model response and triplets
    paragraph_response, triplet_response = generate_response_and_triplet(prompt)
    
    # Update the graph with new information
    graph_memory.store_triplets(triplet_response)
    
    return paragraph_response

def extract_preferences(user_input):
    """
    Extract preferences from the user's input and return a list of preferences.
    """
    preferences = []
    if "historical" in user_input.lower():
        preferences.append("Historical Sites")
    if "food" in user_input.lower():
        preferences.append("Food Experiences")
    if "nature" in user_input.lower():
        preferences.append("Nature Spots")
    if "shopping" in user_input.lower():
        preferences.append("Shopping")
    
    return preferences
