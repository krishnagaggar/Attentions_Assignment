import streamlit as st
import requests

# Set up the title
st.title("One-Day Tour Planning Assistant")

# Define backend URL
BACKEND_URL = "http://127.0.0.1:8000"

# Create session states for storing conversation flow and user data
if "conversation" not in st.session_state:
    st.session_state.conversation = []
    st.session_state.user_data = {
        "user_id": "",
        "city": "",
        "preferences": [],
        "budget": "",
        "days_of_stay": "",
        "start_date": ""
    }

# Function to add message to the conversation
def add_message(role, text):
    st.session_state.conversation.append({"role": role, "text": text})

# Function to display the conversation in a chat-like format
def display_conversation():
    for message in st.session_state.conversation:
        if message["role"] == "bot":
            st.markdown(f"**Bot**: {message['text']}")
        else:
            st.markdown(f"**You**: {message['text']}")

# Display the conversation
display_conversation()

# Step 1: Initializing Tour Request
if not st.session_state.user_data["user_id"]:
    st.subheader("Plan Your One-Day Tour")
    
    # Collect initial details for the tour
    user_id = st.text_input("Your Name", key="name_input")
    city = st.text_input("City you want to explore", key="city_input")
    preferences = st.text_input("Your Interests (comma-separated)", key="preferences_input")
    budget = st.text_input("Budget (e.g., $100)", key="budget_input")
    days_of_stay = st.number_input("Days of stay", min_value=1, max_value=7, step=1)
    start_date = st.date_input("Start Date", key="start_date_input")

    if st.button("Start Planning"):
        # Initialize tour request
        preferences_list = [p.strip() for p in preferences.split(",") if p]
        st.session_state.user_data.update({
            "user_id": user_id,
            "city": city,
            "preferences": preferences_list,
            "budget": budget,
            "days_of_stay": days_of_stay,
            "start_date": str(start_date)
        })

        # Send initial data to backend
        response = requests.post(
            f"{BACKEND_URL}/initialize_tour_request",
            json=st.session_state.user_data
        )

        if response.status_code == 200:
            add_message("bot", "Your tour request has been initialized. Ask me anything or specify more preferences!")
        else:
            add_message("bot", "There was an error initializing your tour request. Please try again.")
        st.experimental_rerun()

# Step 2: Dynamic Conversation (after initializing)
else:
    st.subheader("Continue Planning Your Tour")
    user_input = st.text_input("Enter your question or new preferences", key="user_input")

    if st.button("Send"):
        # Send user input to backend for further processing
        response = requests.post(
            f"{BACKEND_URL}/continue_conversation",
            json={"user_id": st.session_state.user_data["user_id"], "user_input": user_input}
        )

        if response.status_code == 200:
            bot_response = response.json().get("response", "No response available.")
            add_message("user", user_input)
            add_message("bot", bot_response)
        else:
            add_message("bot", "There was an error processing your request. Please try again.")
        st.experimental_rerun()

# Option to restart the conversation
if st.button("Start a New Conversation"):
    st.session_state.conversation = []
    st.session_state.user_data = {
        "user_id": "",
        "city": "",
        "preferences": [],
        "budget": "",
        "days_of_stay": "",
        "start_date": ""
    }
    st.experimental_rerun()
