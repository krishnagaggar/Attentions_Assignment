import outlines
from outlines import function, chain  # Correct import for function and chain

# Define the itinerary generation agent
@function
def itinerary_generation_agent(city, interests, budget):
    return f"Generated itinerary for {city} with interests in {interests} and budget of {budget}."

# Define the weather agent
@function
def weather_agent(city, date):
    return f"Weather forecast for {city} on {date} is sunny."

# Chain the functions together for the complete pipeline
@chain
def tour_planning_pipeline(city, interests, budget, date):
    itinerary = itinerary_generation_agent(city, interests, budget)
    weather = weather_agent(city, date)
    return itinerary, weather
