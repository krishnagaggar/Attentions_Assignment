# backend/tour_request.py

from backend.graph_memory import GraphMemory
from backend.model_endpoint import generate_response_and_triplet  # Corrected import

# Instantiate graph memory
graph_memory = GraphMemory("neo4j://localhost:7687", "neo4j", "password")

def store_user_preferences(user_input):
    # Generate both paragraph and triplet responses
    paragraph_response, triplet_response = generate_response_and_triplet(user_input)
    
    # Store the triplet response in Neo4j
    graph_memory.store_triplets(triplet_response)
    
    # Return the paragraph response for user display
    return paragraph_response

def get_user_preferences_from_memory():
    """Retrieve user preferences from memory and format them for itinerary generation."""
    interests = graph_memory.query_memory("User", "prefers")
    walk_preference = graph_memory.query_memory("User", "has_preference_for_walk")
    # Add other preferences if needed
    return interests, walk_preference

def create_itinerary(user_input):
    # Store user preferences and get paragraph response for the user
    paragraph_response = store_user_preferences(user_input)
    
    # Retrieve user preferences from memory for personalized itinerary
    interests, walk_preference = get_user_preferences_from_memory()
    prompt = (
        f"Create an itinerary for a user who prefers {', '.join(interests)} "
        f"and likes {walk_preference[0] if walk_preference else 'any'} walking activities."
    )
    # Generate the itinerary using the prompt and return the paragraph response
    return paragraph_response, generate_response_and_triplet(prompt)[0]

def adjust_itinerary_with_new_input(new_input):
    # Update memory with new preferences and regenerate itinerary
    paragraph_response = store_user_preferences(new_input)
    return create_itinerary(new_input)[1]
