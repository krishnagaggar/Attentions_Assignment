# backend/model_endpoint.py

# from groq import Groq

# # ##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

# llm_client = Groq(api_key="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")

# def generate_response(prompt) :
#     chat_completion = llm_client.chat.completions.create(
#         messages=[
#             {
#                 "role": "user",
#                 "content": prompt,
#             }
#         ],
#         model="llama3-8b-8192",
#     )
#     return chat_completion.choices[0].message.content
from groq import Groq

# Initialize the LLM client
llm_client = Groq(api_key="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")

def generate_response_and_triplet(prompt):
    # Step 1: Generate the paragraph response
    paragraph_response = llm_client.chat.completions.create(
        messages=[
            {
                "role": "user",
                "content": prompt,
            }
        ],
        model="llama3-8b-8192",
    ).choices[0].message.content
    
    # Step 2: Use paragraph response as input to generate triplet format
    triplet_prompt = (
        f"{prompt}\n\n"
        """Strictily return a 3 word output and no other word. Output must be only of type 'Enity-Relationship-Entity'for Neo4j storage.
          Return only one triplet and no other. For example, if prompt is that I want 
          to explore cultural places like churchgate in mumbai, return "user-cultural-churchgate" 
          and no other word as I will be storing this triplet"""
    )
    
    triplet_response = llm_client.chat.completions.create(
        messages=[
            {
                "role": "user",
                "content": triplet_prompt,
            }
        ],
        model="llama3-8b-8192",
    ).choices[0].message.content
    
    # Return both paragraph and triplet responses
    return paragraph_response, triplet_response

#print(generate_response("Hi, where should I travel in India?"))
# print(chat_completion.choices[0].message.content)

# def generate_response(prompt):
#     inputs = tokenizer(prompt, return_tensors="pt").to(device)
#     output = model.generate(inputs.input_ids, max_length=150)
#     return tokenizer.decode(output[0], skip_special_tokens=True)
# print(generate_response_and_triplet("Tell me places to see in Mumbai in one day with a budget of 1000 rupees"))