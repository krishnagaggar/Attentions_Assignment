from fastapi import FastAPI
from pydantic import BaseModel
from typing import List
from backend.tour_conversation import initialize_tour_request, handle_dynamic_input
from backend.graph_memory import GraphMemory

app = FastAPI()

class InitialTourRequestModel(BaseModel):
    user_id: str
    city: str
    preferences: List[str]
    budget: str
    days_of_stay: int
    start_date: str  # Expected in "YYYY-MM-DD" format

class DynamicInputModel(BaseModel):
    user_id: str
    user_input: str

# Initialize graph memory
graph_memory = GraphMemory(uri="bolt://localhost:7687", user="neo4j", password="12345678")

@app.get("/")
def read_root():
    return {"message": "Welcome to the One-Day Tour Planning API"}

@app.post("/initialize_tour_request")
def initialize_tour_request(request: InitialTourRequestModel):
    """
    Initialize the tour request by storing initial user preferences in the graph.
    """
    response = initialize_tour_request(request)
    return {"message": "Tour request initialized successfully", "response": response}

@app.post("/continue_conversation")
def continue_conversation(input_data: DynamicInputModel):
    """
    Continue the conversation by dynamically handling user input and updating the graph.
    """
    response = handle_dynamic_input(input_data.user_id, input_data.user_input)
    return {"message": "Conversation continued successfully", "response": response}
